use kaggle;
select * from regactiondate;
#Task 1: Identifying Approval Trend
#Determine the number of drugs approved each year and provide insights into the yearly trends
SELECT YEAR(ACTIONDATE) AS Approval_Year, COUNT(*) AS Total_Approvals
FROM regactiondate
GROUP BY YEAR(ACTIONDATE)
ORDER BY Approval_Year;
#Identify the top three years that got the highest and lowest approvals, in descending and ascending order, respectively.
-- Highest approvals
SELECT YEAR(ACTIONDATE) AS Approval_Year, COUNT(*) AS Total_Approvals
FROM regactiondate
GROUP BY YEAR(ACTIONDATE)
ORDER BY Total_Approvals DESC
LIMIT 3;

-- Lowest approvals
SELECT YEAR(ACTIONDATE) AS Approval_Year, COUNT(*) AS Total_Approvals
FROM regactiondate
GROUP BY YEAR(ACTIONDATE)
ORDER BY Total_Approvals
LIMIT 3;

####### Explore approval trends over the years based on sponsors. 

SELECT YEAR(r.ACTIONDATE) AS Approval_Year, a.sponsorapplicant ,  COUNT(*) AS Total_Approvals
FROM application as a inner join regactiondate as r on a.ApplNo = r.ApplNo
GROUP BY YEAR(r.ACTIONDATE), a.SponsorApplicant ORDER BY Approval_Year, Total_Approvals DESC;

#####Rank sponsors based on the total number of approvals they received each year between 1939 and 1960

SELECT YEAR(r.ACTIONDATE) AS Approval_Year, a.sponsorapplicant ,  COUNT(*) AS Total_Approvals
FROM application as a inner join regactiondate as r on a.ApplNo = r.ApplNo 
WHERE YEAR(ACTIONDATE) BETWEEN 1939 AND 1960
GROUP BY YEAR(r.ACTIONDATE), a.SponsorApplicant ORDER BY Approval_Year, Total_Approvals DESC;

----------------------------------------------------

##Task 2: Segmentation Analysis Based on Drug MarketingStatus
### Group products based on MarketingStatus. Provide meaningful insights into the segmentation patterns.

SELECT ProductMktStatus, COUNT(*) AS Total_Products
FROM product
GROUP BY ProductMktStatus;

## Calculate the total number of applications for each MarketingStatus year-wise after the year 2010

SELECT YEAR(r.ACTIONDATE) AS Application_Year, pt.productMktStatus, COUNT(*) AS Total_Applications
FROM product_tecode AS pt
INNER JOIN regactiondate AS r ON pt.ApplNo = r.ApplNo
WHERE YEAR(r.ACTIONDATE) > 2010 AND pt.productMktStatus IS NOT NULL
GROUP BY Application_Year, pt.productMktStatus
ORDER BY Application_Year, Total_Applications DESC;

###Identify the top MarketingStatus with the maximum number of applications and analyze its trend over time.
SELECT YEAR(r.ACTIONDATE) AS Application_Year, pt.productMktStatus, COUNT(*) AS Total_Applications
FROM product_tecode AS pt
INNER JOIN regactiondate AS r ON pt.ApplNo = r.ApplNo
WHERE pt.productMktStatus IS NOT NULL
GROUP BY Application_Year, pt.productMktStatus
ORDER BY Total_Applications DESC;

---------------------------------------------------------------
###Task 3: Analyzing Products

####Categorize Products by dosage form and analyze their distribution###
SELECT Dosage, COUNT(*) AS Total_Products, Form
FROM product
GROUP BY Dosage, Form;

###Calculate the total number of approvals for each dosage form and identify the most successful forms

SELECT Dosage, COUNT(*) AS Total_Products, Form
FROM product
GROUP BY Dosage, Form order by Total_Products DESC;

###Investigate yearly trends related to successful forms.

SELECT YEAR(ACTIONDATE) AS Approval_Year, Dosage, Form, COUNT(*) AS Total_Approvals
FROM regactiondate as r inner join product as p on p.ApplNo = r.ApplNo
GROUP BY Approval_Year, Dosage, Form
ORDER BY Approval_Year, Total_Approvals DESC;

-------------------------------------------------------------------------------
###Task 4: Exploring Therapeutic Classes and Approval Trends
##1. Analyze drug approvals based on therapeutic evaluation code (TE_Code).

SELECT TECode, COUNT(*) AS Total_Approvals
FROM product_tecode
GROUP BY TECode
ORDER BY Total_Approvals DESC;

###Determine the therapeutic evaluation code (TE_Code) with the highest number of Approvals in each year.
SELECT YEAR(ACTIONDATE) AS Approval_Year, TECode, COUNT(*) AS Total_Approvals
FROM regactiondate as r inner join product_tecode as pt on r.ApplNo = pt.ApplNo
GROUP BY Approval_Year, TECode
ORDER BY Approval_Year, Total_Approvals DESC;


